import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        System.out.println("Executing: Assignment 01");
        int[] arr = {64, 34, 25, 12, 22, 11, 90};
        Arrays.sort(arr);
        System.out.println("Java execution verified. Elements: " + Arrays.toString(arr));
    }
}